package com.example.encryptionDemo.data;

public class DecryptionResponseData implements IResponseData {
    private String plain_text;
    private byte[] base64;

    public DecryptionResponseData(String plain_text, byte[] base64) {
        this.plain_text = plain_text;
        this.base64 = base64;
    }

    public String getPlain_text() {
        return plain_text;
    }

    public void setPlain_text(String plain_text) {
        this.plain_text = plain_text;
    }

    public byte[] getBase64() {
        return base64;
    }

    public void setBase64(byte[] base64) {
        this.base64 = base64;
    }

}
