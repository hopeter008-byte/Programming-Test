package com.example.encryptionDemo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

import com.example.encryptionDemo.model.EncryptionModel;
import com.example.encryptionDemo.model.DecryptionModel;

import com.example.encryptionDemo.data.IResponseData;
import com.example.encryptionDemo.data.ResponseData;
import com.example.encryptionDemo.data.EncryptionResponseData;
import com.example.encryptionDemo.data.DecryptionResponseData;

/*

    The following encryption and decryption example will be based on Base64 to process,
    because Base64 can save more storage when compare to Hex

 */

@RestController
@RequestMapping("/aes")
public class EncryptionRestController {

    @PostMapping("/encrypt")
    @ResponseBody
    public ResponseEntity<IResponseData> encrypt(@RequestBody EncryptionModel encryptionModel) {
        try {
            SecretKey key = convertStringToSecretKey(encryptionModel.getAes_key());

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);

            byte[] cipherText = cipher.doFinal(encryptionModel.getPlain_text().getBytes());

            return ResponseEntity.ok(new EncryptionResponseData(Base64.getEncoder().encodeToString(cipherText)));

        } catch (Exception ex) {
            return ResponseEntity.ok(new ResponseData(false, ex.getMessage()));
        }
    }

    @PostMapping("/decrypt")
    @ResponseBody
    public ResponseEntity<IResponseData> decrypt(@RequestBody DecryptionModel decryptionModel) {
        try {
            SecretKey key = convertStringToSecretKey(decryptionModel.getAes_key());

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);

            byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(decryptionModel.getCipher_text()));

            return ResponseEntity.ok(new DecryptionResponseData(new String(plainText), plainText));

        } catch (Exception ex) {
            return ResponseEntity.ok(new ResponseData(false, ex.getMessage()));
        }
    }

    public static SecretKey convertStringToSecretKey(String encodedKey) {
        byte[] decodedKey = Base64.getDecoder().decode(encodedKey);
        SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
        return originalKey;
    }


    /*

        For unit test

     */
    public static EncryptionResponseData testEncrypt(EncryptionModel encryptionModel) {
        byte[] cipherText = new byte[16];

        try {
            SecretKey key = convertStringToSecretKey(encryptionModel.getAes_key());

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);

            cipherText = cipher.doFinal(encryptionModel.getPlain_text().getBytes());

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return new EncryptionResponseData(Base64.getEncoder().encodeToString(cipherText));
    }

    public static DecryptionResponseData testDecrypt(DecryptionModel decryptionModel) {
        byte[] plainText = new byte[99];

        try {
            SecretKey key = convertStringToSecretKey(decryptionModel.getAes_key());

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);

            plainText = cipher.doFinal(Base64.getDecoder().decode(decryptionModel.getCipher_text()));

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return new DecryptionResponseData(new String(plainText), plainText);
    }

}
