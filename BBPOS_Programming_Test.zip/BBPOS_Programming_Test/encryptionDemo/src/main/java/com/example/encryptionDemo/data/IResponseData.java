package com.example.encryptionDemo.data;

public interface IResponseData {

}
