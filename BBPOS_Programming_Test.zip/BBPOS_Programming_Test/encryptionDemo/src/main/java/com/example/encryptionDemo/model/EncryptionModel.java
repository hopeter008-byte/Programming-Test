package com.example.encryptionDemo.model;

public class EncryptionModel {
    private String plain_text;
    private String aes_key;

    public EncryptionModel(String plain_text, String aes_key) {
        this.plain_text = plain_text;
        this.aes_key = aes_key;
    }

    public String getPlain_text() {
        return plain_text;
    }

    public String getAes_key() {
        return aes_key;
    }
}
