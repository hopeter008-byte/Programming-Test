package com.example.encryptionDemo.model;

public class DecryptionModel {
    private String cipher_text;
    private String aes_key;

    public DecryptionModel(String cipher_text, String aes_key) {
        this.cipher_text = cipher_text;
        this.aes_key = aes_key;
    }

    public String getCipher_text() {
        return cipher_text;
    }

    public String getAes_key() {
        return aes_key;
    }
}
