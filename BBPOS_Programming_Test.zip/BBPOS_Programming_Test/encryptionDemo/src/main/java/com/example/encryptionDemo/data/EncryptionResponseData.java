package com.example.encryptionDemo.data;

public class EncryptionResponseData implements IResponseData {
    private String cipher_text;

    public EncryptionResponseData(String cipher_text) {
        this.cipher_text = cipher_text;
    }

    public String getCipher_text() {
        return cipher_text;
    }

    public void setCipher_text(String cipher_text) {
        this.cipher_text = cipher_text;
    }

}


