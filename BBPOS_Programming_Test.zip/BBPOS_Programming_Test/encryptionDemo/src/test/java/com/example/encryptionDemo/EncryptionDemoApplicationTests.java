package com.example.encryptionDemo;

import com.example.encryptionDemo.controller.EncryptionRestController;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.encryptionDemo.model.EncryptionModel;
import com.example.encryptionDemo.model.DecryptionModel;

import com.example.encryptionDemo.data.EncryptionResponseData;
import com.example.encryptionDemo.data.DecryptionResponseData;

@SpringBootTest
class EncryptionDemoApplicationTests {

    @Test
    void givenPlainTextAesKey_whenEncrypt_givenCipherTextAesKey_whenDecrypt_thenCompareOriginalTextPlainText_thenSuccess() {
        String originalText = "Apple";
        String aesKey = "404D635166546A576E5A723475377721";

        EncryptionModel encryptionModel = new EncryptionModel(originalText, aesKey);
        EncryptionResponseData encryptionResponseData = EncryptionRestController.testEncrypt(encryptionModel);
        String cipherText = encryptionResponseData.getCipher_text();

        DecryptionModel decryptionModel = new DecryptionModel(cipherText, aesKey);
        DecryptionResponseData decryptionResponseData = EncryptionRestController.testDecrypt(decryptionModel);
        String plainText = decryptionResponseData.getPlain_text();

        Assertions.assertEquals(originalText, plainText);
    }

}
